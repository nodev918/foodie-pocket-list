# Server Sent Event

It is Way to send events from server to clients.

Here is Example for SSE with basic authentication using gin.

### How to Run? 

1) Run `` go run main.go ``

2) Open ``http://127.0.0.1:8085`` in browser and authorize with username and password given in main.go and see messages.
