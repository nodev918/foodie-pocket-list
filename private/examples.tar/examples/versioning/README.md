# Versioning

This is Endpoint versioning (i.e `/v1/path`) example using custom middleware group in gin-gonic.

### How to Run? 

1) Run ` go run main.go `

2) Test APIs On ` http://localhost:8080 `. 

- For list users in v1, path should be `http://localhost:8080/v1/users`. Likewise, all other routes are working.
