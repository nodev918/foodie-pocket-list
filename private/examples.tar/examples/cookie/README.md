### Cookie

This example shows how to set and get cookies.

1.Build and Run server

2.Visit the login page: http://localhost:8080/login

3.Visit the home page(http://localhost:8080/login) within 30 seconds.

4.Visit the home page(http://localhost:8080/login) after 30 seconds.